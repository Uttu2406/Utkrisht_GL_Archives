﻿using SOLIDReportingSystem.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLIDReportingSystem
{
    public class PdfFormatter : IReportFormatter
    {
        public string Format(string rawData) => $"[PDF FORMAT] {rawData}"; // [cite: 104]
    }
}
