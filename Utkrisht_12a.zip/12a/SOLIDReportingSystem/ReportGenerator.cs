﻿using SOLIDReportingSystem.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLIDReportingSystem
{
    public class ReportGenerator : IReportGenerator
    {
        public string GenerateReportData()
        {
            // Task: Refactor Report Manager into separate classes [cite: 97]
            return "Report Content: Sales Data for Feb 2026";
        }
    }
}
