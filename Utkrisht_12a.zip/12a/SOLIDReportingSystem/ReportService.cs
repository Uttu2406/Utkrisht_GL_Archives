﻿using SOLIDReportingSystem.Interface;

public class ReportService
{
    private readonly IReportGenerator _generator;
    private readonly IReportSaver _saver;
    private readonly IReportFormatter _formatter;

    // Depend on abstractions (interfaces) rather than concrete classes [cite: 122]
    public ReportService(IReportGenerator generator, IReportSaver saver, IReportFormatter formatter)
    {
        _generator = generator;
        _saver = saver;
        _formatter = formatter;
    }

    public void CreateAndStoreReport(string fileName)
    {
        var data = _generator.GenerateReportData();
        var formattedData = _formatter.Format(data);
        _saver.SaveToFile(fileName, formattedData);
    }
}