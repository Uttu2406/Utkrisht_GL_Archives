﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLIDReportingSystem.Interface
{
    public interface IReportGenerator
    {
        string GenerateReportData();
    }
}
