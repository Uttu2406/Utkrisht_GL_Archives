﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLIDReportingSystem.Interface
{
    public interface IReportSaver
    {
        void SaveToFile(string filename, string content); // Only responsible for saving [cite: 99]
    }
}
