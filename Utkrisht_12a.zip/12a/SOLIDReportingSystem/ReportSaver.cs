﻿using SOLIDReportingSystem.Interface;
using System;

public class ReportSaver : IReportSaver
{
    public void SaveToFile(string filename, string content)
    {
        // Task: Responsibility for saving reports [cite: 99]
        Console.WriteLine($"Successfully saved report to {filename}");
    }
}