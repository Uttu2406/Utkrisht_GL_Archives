﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace LibraryManagementLib
{
    public class Library
    {
        // Properties: Lists for books and borrowers [cite: 136]
        public List<Book> Books { get; set; } = new List<Book>();
        public List<Borrower> Borrowers { get; set; } = new List<Borrower>();

        // Method to add a new book to the library [cite: 136]
        public void AddBook(Book book)
        {
            Books.Add(book);
        }

        // Method to register a new borrower [cite: 136]
        public void RegisterBorrower(Borrower borrower)
        {
            Borrowers.Add(borrower);
        }

        // Method to handle borrowing logic [cite: 136, 138]
        public void BorrowBook(string isbn, string libraryCardNumber)
        {
            var book = Books.FirstOrDefault(b => b.ISBN == isbn && !b.IsBorrowed);
            var borrower = Borrowers.FirstOrDefault(b => b.LibraryCardNumber == libraryCardNumber);

            if (book != null && borrower != null)
            {
                book.Borrow(); // Mark book as borrowed [cite: 114]
                borrower.BorrowBook(book); // Associate book with borrower [cite: 115]
            }
        }

        // Method to handle returning logic [cite: 138]
        public void ReturnBook(string isbn, string libraryCardNumber)
        {
            var borrower = Borrowers.FirstOrDefault(b => b.LibraryCardNumber == libraryCardNumber);
            var book = borrower?.BorrowedBooks.FirstOrDefault(b => b.ISBN == isbn);

            if (book != null)
            {
                book.Return(); // Mark book as available [cite: 120]
                borrower.ReturnBook(book); // Remove from borrower's list [cite: 122]
            }
        }
    }
}