using CalculatorLib;

namespace CalculatorTests
{
    public class Tests
    {
        private Calculator _calc;

        [SetUp]
        public void Setup()
        {
            _calc = new Calculator();
        }

        [Test]
        public void Add_ValidInputs_ReturnsSum() // Valid input test
        {
            Assert.AreEqual(10, _calc.Add(7, 3));
        }

        [Test]
        public void Subtract_EdgeCase_SubtractingZero() // Edge case test
        {
            Assert.AreEqual(5, _calc.Subtract(5, 0));
        }

        [Test]
        public void Divide_ByZero_ThrowsException() // Exception test
        {
            Assert.Throws<System.DivideByZeroException>(() => _calc.Divide(10, 0));
        }
    }
}