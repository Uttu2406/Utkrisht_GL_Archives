﻿namespace CalculatorLib
{
    public class Calculator
    {
        public double Add(double a, double b) => a + b;
        public double Subtract(double a, double b) => a - b;
        public double Multiply(double a, double b) => a * b;

        public double Divide(double a, double b)
        {
            if (b == 0)
            {
                // Handle division by zero with an exception 
                throw new System.DivideByZeroException("Cannot divide by zero.");
            }
            return a / b;
        }
    }
}
